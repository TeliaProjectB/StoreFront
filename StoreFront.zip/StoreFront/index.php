<?php

header("Location: ../StoreFront/home/");

?>