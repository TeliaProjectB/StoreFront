function startFunction() {
    var v = document.getElementById("myDIV10");
    if (v.style.display === "none") {
        v.style.display = "block";
    } else {
        v.style.display = "none";
    }
}