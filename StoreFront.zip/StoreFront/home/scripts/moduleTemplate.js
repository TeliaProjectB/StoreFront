define(["retrieveApi"], function(retrieveApi){
	function initModule(){




	}return{
		init: initModule
	}
});