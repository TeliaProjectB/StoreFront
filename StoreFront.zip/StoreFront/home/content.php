
<?php  

include $_SERVER["DOCUMENT_ROOT"]."/StoreFront/homeSplashPage/content.php";

?>

<div class="contentRow" name="Top list"></div>


<div class="contentRow" name="Free"></div>


<div class="contentRow" name="Paid"></div>