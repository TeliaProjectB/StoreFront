<?php

include $_SERVER["DOCUMENT_ROOT"]."/StoreFront/pageStructure/index.php";

?>