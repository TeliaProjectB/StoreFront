<script src="scripts/scrollChecker.js"></script>
    <script src="scripts/fancyClicking.js"></script>
    <script src="scripts/panelSwitcher.js"></script>
	<script src="scripts/commentSystem.js"></script>
	<script src="scripts/sandboxCreator.js"></script>
	<script>
		createMessageBox("commentArea");
		createSandbox("sandboxArea");
	</script>